<?php $__env->startSection('titulo','Perfil Bioquimico'); ?>

<?php $__env->startSection('conteudo'); ?>
    <div class="container" >
        <div class="row">
            <div class="card horizontal" style="width: 45%; float: left; margin: 2%">
                <div class="card-stacked">
                    <div class="card-content" style="box-shadow:  15px 15px 27px #e1e1e3, 15px 15px 27px #ffffff;">

                        <h5 style="padding-bottom: 10px; padding-top: 10px">TG</h5>
                        <h6 style="padding-bottom: 10px">TG data (1): <?php echo e(date('d/m/Y', strtotime($dadosPerfilBioquimico->tgDataUm))); ?></h6>
                        <h6 style="padding-bottom: 10px">TG valor (1): <?php echo e($dadosPerfilBioquimico->tgValorUm); ?></h6>
                        <h6 style="padding-bottom: 10px">TG data (2): <?php echo e(date('d/m/Y', strtotime($dadosPerfilBioquimico->tgDataDois))); ?></h6>
                        <h6 style="padding-bottom: 10px">TG valor (2): <?php echo e($dadosPerfilBioquimico->tgValorDois); ?></h6>

                        <a style="margin-top: 2%" class="btn blue"  href="<?php echo e(route('aluno.cadastro.perfilBioquimico.editar', $dadosPerfilBioquimico->idTreinamento)); ?>">Editar</a>
                    </div>
                </div>
            </div>
            <div class="card horizontal" style="width: 45%; float: left; margin: 2%">
                <div class="card-stacked">
                    <div class="card-content" style="box-shadow:  15px 15px 27px #e1e1e3, 15px 15px 27px #ffffff;">
                        <h5 style="padding-bottom: 10px">Glicemia</h5>
                        <h6 style="padding-bottom: 10px">Glicemia data (1): <?php echo e(date('d/m/Y', strtotime($dadosPerfilBioquimico->glicemiaDataUm))); ?></h6>
                        <h6 style="padding-bottom: 10px">Glicemia valor (1): <?php echo e($dadosPerfilBioquimico->glicemiaValorUm); ?></h6>
                        <h6 style="padding-bottom: 10px">Glicemia data (2):<?php echo e(date('d/m/Y', strtotime( $dadosPerfilBioquimico->glicemiaDataDois ))); ?></h6>
                        <h6 style="padding-bottom: 10px">Glicemia valor (2): <?php echo e($dadosPerfilBioquimico->glicemiaValorDois); ?></h6>
                        <a style="margin-top: 2%" class="btn blue"  href="<?php echo e(route('aluno.cadastro.perfilBioquimico.editar', $dadosPerfilBioquimico->idTreinamento)); ?>">Editar</a>

                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="card horizontal" style="width: 45%; float: left; margin: 2%">
                <div class="card-stacked">
                    <div class="card-content" style="box-shadow:  15px 15px 27px #e1e1e3, 15px 15px 27px #ffffff;">
                        <h5 style="padding-bottom: 10px; padding-top: 10px">Insulina</h5>
                        <h6 style="padding-bottom: 10px">Insulina data (1): <?php echo e(date('d/m/Y', strtotime($dadosPerfilBioquimico->insulinaDataUm))); ?></h6>
                        <h6 style="padding-bottom: 10px">Insulina valor (1): <?php echo e($dadosPerfilBioquimico->insulinaValorUm); ?></h6>
                        <h6 style="padding-bottom: 10px">Insulina data (2): <?php echo e(date('d/m/Y', strtotime($dadosPerfilBioquimico->insulinaDataDois))); ?></h6>
                        <h6 style="padding-bottom: 10px">Insulina valor (2): <?php echo e($dadosPerfilBioquimico->insulinaValorDois); ?></h6>
                        <a style="margin-top: 2%" class="btn blue"  href="<?php echo e(route('aluno.cadastro.perfilBioquimico.editar', $dadosPerfilBioquimico->idTreinamento)); ?>">Editar</a>

                    </div>
                </div>
            </div>
            <div class="card horizontal" style="width: 45%; float: left; margin: 2%">
                <div class="card-stacked">
                    <div class="card-content" style="box-shadow:  15px 15px 27px #e1e1e3, 15px 15px 27px #ffffff;">
                        <h5 style="padding-bottom: 10px; padding-top: 10px">Creatina</h5>
                        <h6 style="padding-bottom: 10px">Creatina data (1): <?php echo e(date('d/m/Y', strtotime($dadosPerfilBioquimico->creatinaDataUm))); ?></h6>
                        <h6 style="padding-bottom: 10px">Creatina valor (1): <?php echo e($dadosPerfilBioquimico->creatinaValorUm); ?></h6>
                        <h6 style="padding-bottom: 10px">Cretina data (2):<?php echo e(date('d/m/Y', strtotime($dadosPerfilBioquimico->creatinaDataDois))); ?></h6>
                        <h6 style="padding-bottom: 10px">Creatinha valor (2): <?php echo e($dadosPerfilBioquimico->creatinaValorDois); ?></h6>
                        <a style="margin-top: 2%" class="btn blue"  href="<?php echo e(route('aluno.cadastro.perfilBioquimico.editar', $dadosPerfilBioquimico->idTreinamento)); ?>">Editar</a>

                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="card horizontal" style="width: 45%; float: left; margin: 2%">
                <div class="card-stacked">
                    <div class="card-content" style="box-shadow:  15px 15px 27px #e1e1e3, 15px 15px 27px #ffffff;">
                        <h5 style="padding-bottom: 10px; padding-top: 10px">CT</h5>
                        <h6 style="padding-bottom: 10px">CT data (1): <?php echo e(date('d/m/Y', strtotime($dadosPerfilBioquimico->ctDataUm))); ?></h6>
                        <h6 style="padding-bottom: 10px">CT valor (1): <?php echo e($dadosPerfilBioquimico->ctValorUm); ?></h6>
                        <h6 style="padding-bottom: 10px">CT data (2): <?php echo e(date('d/m/Y', strtotime($dadosPerfilBioquimico->ctDataDois))); ?></h6>
                        <h6 style="padding-bottom: 10px">CT valor (2): <?php echo e($dadosPerfilBioquimico->ctValorDois); ?></h6>
                        <a style="margin-top: 2%" class="btn blue"  href="<?php echo e(route('aluno.cadastro.perfilBioquimico.editar', $dadosPerfilBioquimico->idTreinamento)); ?>">Editar</a>

                    </div>
                </div>
            </div>
            <div class="card horizontal" style="width: 45%; float: left; margin: 2%">
                <div class="card-stacked">
                    <div class="card-content" style="box-shadow:  15px 15px 27px #e1e1e3, 15px 15px 27px #ffffff;">
                        <h5 style="padding-bottom: 10px; padding-top: 10px">HDL</h5>
                        <h6 style="padding-bottom: 10px">HDL data (1): <?php echo e(date('d/m/Y', strtotime($dadosPerfilBioquimico->hdlDataUm))); ?></h6>
                        <h6 style="padding-bottom: 10px">HDL valor (1): <?php echo e($dadosPerfilBioquimico->hdlValorUm); ?></h6>
                        <h6 style="padding-bottom: 10px">HDL data (2):<?php echo e(date('d/m/Y', strtotime($dadosPerfilBioquimico->hdlDataDois))); ?></h6>
                        <h6 style="padding-bottom: 10px">HDL valor (2): <?php echo e($dadosPerfilBioquimico->hdlValorDois); ?></h6>
                        <a style="margin-top: 2%" class="btn blue"  href="<?php echo e(route('aluno.cadastro.perfilBioquimico.editar', $dadosPerfilBioquimico->idTreinamento)); ?>">Editar</a>

                    </div>
                </div>
            </div>
        </div>
            <div class="row">
                <div class="card horizontal" style="width: 45%; float: left; margin: 2%">
                    <div class="card-stacked">
                        <div class="card-content" style="box-shadow:  15px 15px 27px #e1e1e3, 15px 15px 27px #ffffff;">
                            <h5 style="padding-bottom: 10px; padding-top: 10px">LDL</h5>
                            <h6 style="padding-bottom: 10px">LDL data (1): <?php echo e(date('d/m/Y', strtotime($dadosPerfilBioquimico->ldlDataUm))); ?></h6>
                            <h6 style="padding-bottom: 10px">LDL valor (1): <?php echo e($dadosPerfilBioquimico->ldlValorUm); ?></h6>
                            <h6 style="padding-bottom: 10px">LDL data (2):<?php echo e(date('d/m/Y', strtotime($dadosPerfilBioquimico->ldlDataDois))); ?></h6>
                            <h6 style="padding-bottom: 10px">LDL valor (2): <?php echo e($dadosPerfilBioquimico->ldlValorDois); ?></h6>
                            <a style="margin-top: 2%" class="btn blue"  href="<?php echo e(route('aluno.cadastro.perfilBioquimico.editar', $dadosPerfilBioquimico->idTreinamento)); ?>">Editar</a>

                        </div>
                    </div>
                </div>
            </div>
        </div>

        <script>
            $(document).ready(function(){
                $('#Data').mask('99/99/9999');
            });

            $(document).ready(function(){
                $('#Data2').mask('99/99/9999');
            });
        </script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/minski/Desktop/Faculdade/ClinicaEDF/resources/views/aluno/aluno_perfil_bioquimico.blade.php ENDPATH**/ ?>