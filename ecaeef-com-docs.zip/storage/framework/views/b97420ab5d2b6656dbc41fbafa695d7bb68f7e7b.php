

<?php echo $__env->make('layout._includes.topo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->yieldContent('conteudo'); ?>

<?php echo $__env->make('layout._includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /home/minski/Desktop/Faculdade/ClinicaEDF/resources/views/layout/site.blade.php ENDPATH**/ ?>