<?php $__env->startSection('titulo','Lista de Alunos'); ?>

<?php $__env->startSection('conteudo'); ?>
    <div class="container">
        <br/>
        <h3 class="center">Alunos</h3>
        <?php if(isset($errors) && count ($errors) > 0): ?>
            <div class="alert alert-danger">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p align="center"><?php echo e($error); ?></p>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
        <br/><br/><br/>
        <div class="row">
            <table>
                <thead>
                <tr>
                    <th>Nome</th>
                    <th>Dados Pessoais</th>
                    <th>Treinamentos</th>
                    <th>Trocar professor</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $alunos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aluno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($aluno->nome); ?></td>
                        <td>
                            <a class="btn deep green" href="<?php echo e(route('aluno.dados.pessoais', $aluno->id)); ?>">Dados Pessoais</a>
                        </td>
                        <td>
                            <a class="btn deep orange" href="<?php echo e(route('aluno.treinamentos',$aluno->id)); ?>">Treinamentos</a>
                        </td>
                        <td>
                            <a class="btn red" href="<?php echo e(route('aluno.trocar.professor',$aluno->id)); ?>">Trocar Professor</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div class="row">
            <a class="btn blue" href="<?php echo e(route('aluno.cadastro.dados')); ?>">Cadastrar novo aluno</a>
        </div>
        <div class="row" align="center">
            <?php echo e($alunos->links('vendor.pagination.materializecss')); ?>

        </div>


    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/minski/Desktop/Faculdade/ClinicaEDF/resources/views/aluno/aluno_lista_admin.blade.php ENDPATH**/ ?>