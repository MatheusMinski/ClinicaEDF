<?php $__env->startSection('titulo', 'Home'); ?>

<?php $__env->startSection('conteudo'); ?>
    <!doctype html>
<html>
<head>


    <title>eCAEEF Home Page</title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

    <!-- Styles -->

</head>
<body>
<div class="content">
    <div class="center" style="padding-top: 50px">
        <img id="logo" src="https://i.ibb.co/Z2kjgcb/as.jpg" alt="as" border="0">
    </div>
</div>
</div>
</body>
</html>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/minski/Desktop/Faculdade/ClinicaEDF/resources/views/home.blade.php ENDPATH**/ ?>