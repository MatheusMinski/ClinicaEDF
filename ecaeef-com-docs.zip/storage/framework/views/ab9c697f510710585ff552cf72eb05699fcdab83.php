<!DOCTYPE html>


<html>
<head>
    <title><?php echo $__env->yieldContent('titulo'); ?></title>
    <!--Import Google Icon Font-->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <!--Import materialize.css-->

    <!-- Compiled and minified CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">


    <!--Let browser know website is optimized for mobile-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>


</head>

<body style="width: 100%">
<header>

    <link rel="stylesheet" href="<?php echo asset('css/style.css')?>" type="text/css">
    <link rel="stylesheet" type="text/css" href="//assets.locaweb.com.br/locastyle/2.0.6/stylesheets/locastyle.css">


    <nav class="yellow">
        <a href="#" data-target="slide-out" class="sidenav-trigger show-on-large"><i class="material-icons">menu</i></a>
        <a href="<?php echo e(route('home')); ?>"  style="color: #1d2124" class="brand-logo center">Home</a>
        <ul class="right hide-on-med-and-down">
            <?php if(!Auth::guest()): ?>
                <li><a class="upBtn" name="btnSair" href="<?php echo e(route('sair')); ?>" style="color: #1d2124">Sair</a></li>
            <?php else: ?>
                <li><a class="upBtn" name="Btnlog" style="color: #1d2124" href="<?php echo e(route('login')); ?>">Login</a></li>
            <?php endif; ?>
        </ul>
    </nav>

    <ul id="slide-out" class="sidenav">
        <?php if(!Auth::guest()): ?>
            <?php
                $fullName = Auth::user()->nome;
                $firstName = explode(" ", $fullName);
            ?>
            <li><a class = "upBtn"style=" color: #1d2124"><?php echo e($firstName[0]); ?></a></li>
            <li><a class="upBtn" name="btnAlunos" href="<?php echo e(route('aluno.lista')); ?>"style=" color: #1d2124">Alunos</a></li>
            <li><a class="upBtn" name="btnListaEspera" href="<?php echo e(route('lista.espera')); ?>" style="color: #1d2124">Lista de Espera</a></li>
            <li><a class="upBtn" name="btnCalendario" href="" style="color: #1d2124">Calendario</a></li>
            <li><a class="upBtn" name="btnProf" href="<?php echo e(route('lista.professor')); ?>" style="color: #1d2124">Professores</a></li>
            <li><a class="upBtn" name="BtnEmp" href="<?php echo e(route('lista.emprestimos')); ?>" style="color: #1d2124">Empréstimos</a></li>
            <li><a class="upBtn" name="BtnEq" href="<?php echo e(route('lista.equipamentos')); ?>" style="color: #1d2124">Equipamentos</a></li>
            <li><a class="upBtn" name="BtnAdmin" href="<?php echo e(route('alunos.admin')); ?>" style="color: #1d2124">Admin</a></li>
        <?php endif; ?>
        <?php if(!Auth::guest()): ?>
            <li><a class="upBtn" name="btnSair" href="<?php echo e(route('sair')); ?>" style="color: #1d2124">Sair</a></li>
        <?php else: ?>
            <li><a class="upBtn" name="Btnlog" style="color: #1d2124" href="<?php echo e(route('login')); ?>">Login</a></li>
        <?php endif; ?>

    </ul>


    <script async="" src="//www.google-analytics.com/analytics.js" style="display: none !important;"></script>
    <script type="text/javascript" src="//code.jquery.com/jquery-2.0.3.min.js"></script>
    <script type="text/javascript" src="//assets.locaweb.com.br/locastyle/2.0.6/javascripts/locastyle.js"></script>
    <script>
        $(document).ready(function(){
            $('.sidenav').sidenav();
        });
    </script>

</header>

<?php /**PATH /home/minski/Desktop/Faculdade/ClinicaEDF/resources/views/layout/_includes/topo.blade.php ENDPATH**/ ?>