<!--JavaScript at end of body for optimized loading-->


<!-- Compiled and minified JavaScript -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
<script type="text/javascript" src="js/jquery-1.2.6.pack.js"></script>
<script type="text/javascript" src="js/jquery.maskedinput-1.1.4.pack.js"></script>

<script type="text/javascript">
    $(document).ready(function () {
        Materialize.updateTextFields();
        $('.sidenav').sidenav();
        $('select').formSelect();
        $('.datepicker').datepicker();
    });

    $(document).ready(function(){
        $('select').formSelect();
    });

    $(document).ready(function(){
        $('.datepicker').datepicker();
    });


</script>

</body>
</html>
<?php /**PATH /home/minski/Desktop/Faculdade/ClinicaEDF/resources/views/layout/_includes/footer.blade.php ENDPATH**/ ?>