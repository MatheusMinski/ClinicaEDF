<?php $__env->startSection('titulo','Consultas'); ?>

<?php $__env->startSection('conteudo'); ?>
<div class="container">
    <!--FORMULÁRIO DE CADASTRO-->
    <div id="cadastro">
        <form method="post" action="<?php echo e(route('aluno.cadastro.consultas.salvar')); ?>">
            <?php echo e(csrf_field()); ?>


            <input name="idTreinamento" value="<?php echo e($idTreinamento); ?>" type="hidden"/>

            <div class="row" style="padding-top: 5%">
                <div class="col s12 center">
                    <h4>Consultas médicas nos últimos 12 meses</h4>
                </div>
            </div>

            <div class="row">
                <div class="col s12">
                    <?php if(isset($errors) && count ($errors) > 0): ?>
                        <div class="alert alert-danger">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <p><?php echo e($error); ?></p>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="row">
                <div class="col s8">
                    <label for="">Especialidade</label>
                    <input value="" name="especialidade" class="form-control" required="required" maxlength="50" type="text" placeholder="" />
                </div>
                <div class="col s4">
                    <label for="">Data Aproximada</label>
                    <input value="" name="dataAproximada" class="form-control" required="required" maxlength="50" id="Data" placeholder="00/00/0000" />
                </div>
            </div>

            <div class="row">
                <div class="col s12">
                    <label for="">Motivo</label>
                    <textarea value="" name="motivo" class="form-control" required="required" maxlength="50" type="text" placeholder=""></textarea>
                </div>
            </div>
            <div class="row">
                <div class="col s12">
                    <button  class="btn blue"> Adicionar </button>
                </div>
            </div>
        </form>
    </div>

    <div style="padding-top: 10%; padding-bottom: 15%">

        <h5 class="center">Exames Cadastrados</h5>
        <table>
            <thead>
            <th style="width: 20%">Data aproximada</th>
            <th style="width: 50%">Especialidade</th>
            <th style="width: 30%">Resultados Principais</th>

            </thead>
            <tbody>
            <?php $__currentLoopData = $dadosConsultas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consulta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e(date('d/m/Y', strtotime($consulta->dataAproximada))); ?></td>
                    <td><?php echo e($consulta->especialidade); ?></td>
                    <td><button data-target="modal1-<?php echo e($consulta->id); ?>" class="btn green modal-trigger">Motivo</button>
                    <td>
                        <a class="btn orange" href="<?php echo e(route('aluno.cadastro.consultas.editar', ['idConsulta' => $consulta->id,'idTreinamento' => $idTreinamento])); ?>">Editar</a>
                    </td>

                    <div id="modal1-<?php echo e($consulta->id); ?>" class="modal">
                        <div class="modal-content center">
                            <h4 style="padding-bottom: 5%">Motivo:</h4>
                            <h6><?php echo e($consulta->motivo); ?></h6>
                        </div>
                        <div class="modal-footer">
                            <a href="#!" class="modal-close waves-effect waves-green btn-flat">Ok</a>
                        </div>
                    </div>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

    </div>
</div>


<script>
    $(document).ready(function(){
        $('#Data').mask('99/99/9999');
    });
    $(document).ready(function(){
        $('.modal').modal();
    });
</script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/minski/Desktop/Faculdade/ClinicaEDF/resources/views/aluno/aluno_cadastro_consultas.blade.php ENDPATH**/ ?>