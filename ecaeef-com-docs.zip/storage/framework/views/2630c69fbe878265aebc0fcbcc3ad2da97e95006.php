<?php $__env->startSection('titulo','Treinamentos'); ?>

<?php $__env->startSection('conteudo'); ?>
    <div class="container">
    <h2 class="center">Dados cadastrados com sucesso!</h2>
        <h6 class="center">Você será redirecionado em breve...</h6>
    </div>

<script>
    $(document).ready(function () {
        // Handler for .ready() called.
        var jobs = <?php echo json_encode($idAluno); ?>;
        if((jobs == "Lista de Alunos")){
            window.setTimeout(function () {
                location.href = '<?php echo e(route('aluno.lista')); ?>';
            }, 3000);
        }else{
            window.setTimeout(function () {
                location.href = '<?php echo e(route('aluno.cadastro.endereco', ['idAluno' => $idAluno])); ?>';
            }, 3000);
        }


    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/minski/Desktop/Faculdade/ClinicaEDF/resources/views/aluno/cadastro_sucesso.blade.php ENDPATH**/ ?>