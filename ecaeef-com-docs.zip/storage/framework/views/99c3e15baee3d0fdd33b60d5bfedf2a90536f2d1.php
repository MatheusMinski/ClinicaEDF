<table>
    <thead>
    <tr>
        <th>nome</th>
        <th>dataNasc</th>
        <th>idade</th>
        <th>sexo</th>
        <th>encaminhamento</th>
        <th>nomeDoProfissional</th>
        <th>especialidadeDoProfissional</th>
        <th>motivoEncaminhamento</th>
        <th>saudeGeral</th>
        <th>fumaCigarro</th>
        <th>fumaCigarroQuantidadeDia</th>
        <th>jaFumou</th>
        <th>jaFumouQuantidadeAnos</th>
        <th>jaFumouParouAQuantoTempoAnos</th>
        <th>descricaoProblemaSaude</th>
        <th>caiu12Meses</th>
        <th>quantasQuedas</th>
        <th>data</th>
        <th>razaoQueda</th>
        <th>localQueda</th>
        <th>hospitalizacao</th>
        <th>objetivosAoProcurarAClinica</th>
        <th>jaTentouResolverAntes</th>
        <th>quantasVezes</th>
        <th>jaDesistiu</th>
        <th>motivoDesistencia</th>
        <th>dorRegiaoDoCorpo</th>
        <th>descricaoSintomaDor1</th>
        <th>ProfissionalQueTratou1</th>
        <th>inicioFim1</th>
        <th>EVA1</th>
        <th>descricaoSintomaDor2</th>
        <th>ProfissionalQueTratou2</th>
        <th>inicioFim2</th>
        <th>EVA2</th>
        <th>descricaoSintomaDor3</th>
        <th>ProfissionalQueTratou3</th>
        <th>inicioFim3</th>
        <th>EVA3</th>
        <th>descricaoSintomaDor4</th>
        <th>ProfissionalQueTratou4</th>
        <th>inicioFim4</th>
        <th>EVA4</th>
        <th>esforcosTarefaCasa</th>
        <th>esforcoAndarForaDeCasa</th>
        <th>esforcoLazer</th>
        <th>esforcoTrabalho</th>
        <th>exercicioFisicoRegular</th>
        <th>quantasVezesSemana</th>
        <th>esforcoParaEsseExercicio</th>
        <th>pressaoArterialPAS</th>
        <th>pressaoArterialPAD</th>
        <th>freqCardiacaMedia</th>
        <th>saturacaoO2</th>
        <th>capacidadeVital1</th>
        <th>capacidadeVital2</th>
        <th>capacidadeVital3</th>
        <th>massaCorporal</th>
        <th>estaturaCm</th>
        <th>circunferenciaCintura</th>
        <th>circunferenciaPescoco</th>
        <th>massaMagra</th>
        <th>gordura</th>
        <th>h2o</th>
        <th>tmb</th>
        <th>sentarEAlcancarMaior</th>
        <th>ombroDireito</th>
        <th>ombroEsquerdo</th>
        <th>apoioUnipodalDireita</th>
        <th>apoioUnipodalEsquerda</th>
        <th>alcanceFuncional</th>
        <th>pressaoManualDireita</th>
        <th>pressaoManualEsquerda</th>
        <th>sentarLevantarCadeiraRep</th>
        <th>sentarLevantarCadeiraFCMax</th>
        <th>distanciaTeste6Min</th>
        <th>pedometroTeste6Min</th>
        <th>fcTeste6Min1</th>
        <th>fcTeste6Min2</th>
        <th>fcTeste6Min3</th>
        <th>fcTeste6Min4</th>
        <th>fcTeste6Min5</th>
        <th>fcTeste6Min6</th>
        <th>fcRecuperacaoUmMin</th>
        <th>fcRecuperacaoTresMin</th>
        <th>fcRecuperacaoCincoMin</th>
        <th>pasTesteUmMin</th>
        <th>pasTesteCincoMin</th>
        <th>pasTesteDezMin</th>
        <th>padTesteUmMin</th>
        <th>padTesteCincoMin</th>
        <th>padTesteDezMin</th>
        <th>testeExtra1</th>
        <th>respostaTesteExtraUm</th>
        <th>testeExtra2</th>
        <th>respostaTesteExtraDois</th>
        <th>testeExtra3</th>
        <th>respostaTesteExtraTres</th>
        <th>testeExtra4</th>
        <th>respostaTesteExtraQuatro</th>
        <th>glicemiaDataUm</th>
        <th>glicemiaValorUm</th>
        <th>glicemiaDataDois</th>
        <th>glicemiaValorDois</th>
        <th>insulinaDataUm</th>
        <th>insulinaValorUm</th>
        <th>insulinaDataDois</th>
        <th>insulinaValorDois</th>
        <th>creatinaDataUm</th>
        <th>creatinaValorUm</th>
        <th>creatinaDataDois</th>
        <th>creatinaValorDois</th>
        <th>ctDataUm</th>
        <th>ctValorUm</th>
        <th>ctDataDois</th>
        <th>ctValorDois</th>
        <th>hdlDataUm</th>
        <th>hdlValorUm</th>
        <th>hdlDataDois</th>
        <th>hdlValorDois</th>
        <th>ldlDataUm</th>
        <th>ldlValorUm</th>
        <th>ldlDataDois</th>
        <th>ldlValorDois</th>
        <th>tgDataUm</th>
        <th>tgValorUm</th>
        <th>tgDataDois</th>
        <th>tgValorDois</th>




































    </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $alunos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aluno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($aluno->nome ?? " "); ?></td>
            <td><?php echo e($aluno->dataNasc ?? " "); ?></td>
            <td><?php echo e($aluno->idade ?? " "); ?></td>
            <td><?php echo e($aluno->sexo ?? " "); ?></td>
            <td><?php echo e($aluno->encaminhamento ?? " "); ?></td>
            <td><?php echo e($aluno->nomeDoProfissional ?? " "); ?></td>
            <td><?php echo e($aluno->especialidadeDoProfissional ?? " "); ?></td>
            <td><?php echo e($aluno->motivoEncaminhamento ?? " "); ?></td>
            <td><?php echo e($aluno->saudeGeral ?? " "); ?></td>
            <td><?php echo e($aluno->fumaCigarro ?? " "); ?></td>
            <td><?php echo e($aluno->fumaCigarroQuantidadeDia ?? " "); ?></td>
            <td><?php echo e($aluno->jaFumou ?? " "); ?></td>
            <td><?php echo e($aluno->jaFumouQuantidadeAnos ?? " "); ?></td>
            <td><?php echo e($aluno->jaFumouParouAQuantoTempoAnos ?? " "); ?></td>
            <td><?php echo e($aluno->descricaoProblemaSaude ?? " "); ?></td>
            <td><?php echo e($aluno->caiu12Meses ?? " "); ?></td>
            <td><?php echo e($aluno->quantasQuedas ?? " "); ?></td>
            <td><?php echo e($aluno->data ?? " "); ?></td>
            <td><?php echo e($aluno->razaoQueda ?? " "); ?></td>
            <td><?php echo e($aluno->localQueda ?? " "); ?></td>
            <td><?php echo e($aluno->hospitalizacao ?? " "); ?></td>
            <td><?php echo e($aluno->objetivosAoProcurarAClinica ?? " "); ?></td>
            <td><?php echo e($aluno->jaTentouResolverAntes ?? " "); ?></td>
            <td><?php echo e($aluno->quantasVezes ?? " "); ?></td>
            <td><?php echo e($aluno->jaDesistiu ?? " "); ?></td>
            <td><?php echo e($aluno->motivoDesistencia ?? " "); ?></td>
            <td><?php echo e($aluno->dorRegiaoDoCorpo ?? " "); ?></td>
            <td><?php echo e($aluno->descricaoSintomaDor1 ?? " "); ?></td>
            <td><?php echo e($aluno->ProfissionalQueTratou1 ?? " "); ?></td>
            <td><?php echo e($aluno->inicioFim1 ?? " "); ?></td>
            <td><?php echo e($aluno->EVA1 ?? " "); ?></td>
            <td><?php echo e($aluno->descricaoSintomaDor2 ?? " "); ?></td>
            <td><?php echo e($aluno->ProfissionalQueTratou2 ?? " "); ?></td>
            <td><?php echo e($aluno->inicioFim2 ?? " "); ?></td>
            <td><?php echo e($aluno->EVA2 ?? " "); ?></td>
            <td><?php echo e($aluno->descricaoSintomaDor3 ?? " "); ?></td>
            <td><?php echo e($aluno->ProfissionalQueTratou3 ?? " "); ?></td>
            <td><?php echo e($aluno->inicioFim3 ?? " "); ?></td>
            <td><?php echo e($aluno->EVA3 ?? " "); ?></td>
            <td><?php echo e($aluno->descricaoSintomaDor4 ?? " "); ?></td>
            <td><?php echo e($aluno->ProfissionalQueTratou4 ?? " "); ?></td>
            <td><?php echo e($aluno->inicioFim4 ?? " "); ?></td>
            <td><?php echo e($aluno->EVA4 ?? " "); ?></td>
            <td><?php echo e($aluno->esforcosTarefaCasa ?? " "); ?></td>
            <td><?php echo e($aluno->esforcoAndarForaDeCasa ?? " "); ?></td>
            <td><?php echo e($aluno->esforcoLazer ?? " "); ?></td>
            <td><?php echo e($aluno->esforcoTrabalho ?? " "); ?></td>
            <td><?php echo e($aluno->exercicioFisicoRegular ?? " "); ?></td>
            <td><?php echo e($aluno->quantasVezesSemana ?? " "); ?></td>
            <td><?php echo e($aluno->esforcoParaEsseExercicio ?? " "); ?></td>
            <td><?php echo e($aluno->pressaoArterialPAS ?? " "); ?></td>
            <td><?php echo e($aluno->pressaoArterialPAD ?? " "); ?></td>
            <td><?php echo e($aluno->freqCardiacaMedia ?? " "); ?></td>
            <td><?php echo e($aluno->saturacaoO2 ?? " "); ?></td>
            <td><?php echo e($aluno->capacidadeVital1 ?? " "); ?></td>
            <td><?php echo e($aluno->capacidadeVital2 ?? " "); ?></td>
            <td><?php echo e($aluno->capacidadeVital3 ?? " "); ?></td>
            <td><?php echo e($aluno->massaCorporal ?? " "); ?></td>
            <td><?php echo e($aluno->estaturaCm ?? " "); ?></td>
            <td><?php echo e($aluno->circunferenciaCintura ?? " "); ?></td>
            <td><?php echo e($aluno->circunferenciaPescoco ?? " "); ?></td>
            <td><?php echo e($aluno->massaMagra ?? " "); ?></td>
            <td><?php echo e($aluno->gordura ?? " "); ?></td>
            <td><?php echo e($aluno->h2o ?? " "); ?></td>
            <td><?php echo e($aluno->tmb ?? " "); ?></td>
            <td><?php echo e($aluno->sentarEAlcancarMaior ?? " "); ?></td>
            <td><?php echo e($aluno->ombroDireito ?? " "); ?></td>
            <td><?php echo e($aluno->ombroEsquerdo ?? " "); ?></td>
            <td><?php echo e($aluno->apoioUnipodalDireita ?? " "); ?></td>
            <td><?php echo e($aluno->apoioUnipodalEsquerda ?? " "); ?></td>
            <td><?php echo e($aluno->alcanceFuncional ?? " "); ?></td>
            <td><?php echo e($aluno->pressaoManualDireita ?? " "); ?></td>
            <td><?php echo e($aluno->pressaoManualEsquerda ?? " "); ?></td>
            <td><?php echo e($aluno->sentarLevantarCadeiraRep ?? " "); ?></td>
            <td><?php echo e($aluno->sentarLevantarCadeiraFCMax ?? " "); ?></td>
            <td><?php echo e($aluno->distanciaTeste6Min ?? " "); ?></td>
            <td><?php echo e($aluno->pedometroTeste6Min ?? " "); ?></td>
            <td><?php echo e($aluno->fcTeste6Min1 ?? " "); ?></td>
            <td><?php echo e($aluno->fcTeste6Min2 ?? " "); ?></td>
            <td><?php echo e($aluno->fcTeste6Min3 ?? " "); ?></td>
            <td><?php echo e($aluno->fcTeste6Min4 ?? " "); ?></td>
            <td><?php echo e($aluno->fcTeste6Min5 ?? " "); ?></td>
            <td><?php echo e($aluno->fcTeste6Min6 ?? " "); ?></td>
            <td><?php echo e($aluno->fcRecuperacaoUmMin ?? " "); ?></td>
            <td><?php echo e($aluno->fcRecuperacaoTresMin ?? " "); ?></td>
            <td><?php echo e($aluno->fcRecuperacaoCincoMin ?? " "); ?></td>
            <td><?php echo e($aluno->pasTesteUmMin ?? " "); ?></td>
            <td><?php echo e($aluno->pasTesteCincoMin ?? " "); ?></td>
            <td><?php echo e($aluno->pasTesteDezMin ?? " "); ?></td>
            <td><?php echo e($aluno->padTesteUmMin ?? " "); ?></td>
            <td><?php echo e($aluno->padTesteCincoMin ?? " "); ?></td>
            <td><?php echo e($aluno->padTesteDezMin ?? " "); ?></td>
            <td><?php echo e($aluno->testeExtra1 ?? " "); ?></td>
            <td><?php echo e($aluno->respostaTesteExtraUm ?? " "); ?></td>
            <td><?php echo e($aluno->testeExtra2 ?? " "); ?></td>
            <td><?php echo e($aluno->respostaTesteExtraDois ?? " "); ?></td>
            <td><?php echo e($aluno->testeExtra3 ?? " "); ?></td>
            <td><?php echo e($aluno->respostaTesteExtraTres ?? " "); ?></td>
            <td><?php echo e($aluno->testeExtra4 ?? " "); ?></td>
            <td><?php echo e($aluno->respostaTesteExtraQuatro ?? " "); ?></td>
            <td><?php echo e($aluno->glicemiaDataUm ?? " "); ?></td>
            <td><?php echo e($aluno->glicemiaValorUm ?? " "); ?></td>
            <td><?php echo e($aluno->glicemiaDataDois ?? " "); ?></td>
            <td><?php echo e($aluno->glicemiaValorDois ?? " "); ?></td>
            <td><?php echo e($aluno->insulinaDataUm ?? " "); ?></td>
            <td><?php echo e($aluno->insulinaValorUm ?? " "); ?></td>
            <td><?php echo e($aluno->insulinaDataDois ?? " "); ?></td>
            <td><?php echo e($aluno->insulinaValorDois ?? " "); ?></td>
            <td><?php echo e($aluno->creatinaDataUm ?? " "); ?></td>
            <td><?php echo e($aluno->creatinaValorUm ?? " "); ?></td>
            <td><?php echo e($aluno->creatinaDataDois ?? " "); ?></td>
            <td><?php echo e($aluno->creatinaValorDois ?? " "); ?></td>
            <td><?php echo e($aluno->ctDataUm ?? " "); ?></td>
            <td><?php echo e($aluno->ctValorUm ?? " "); ?></td>
            <td><?php echo e($aluno->ctDataDois ?? " "); ?></td>
            <td><?php echo e($aluno->ctValorDois ?? " "); ?></td>
            <td><?php echo e($aluno->hdlDataUm ?? " "); ?></td>
            <td><?php echo e($aluno->hdlValorUm ?? " "); ?></td>
            <td><?php echo e($aluno->hdlDataDois ?? " "); ?></td>
            <td><?php echo e($aluno->hdlValorDois ?? " "); ?></td>
            <td><?php echo e($aluno->ldlDataUm ?? " "); ?></td>
            <td><?php echo e($aluno->ldlValorUm ?? " "); ?></td>
            <td><?php echo e($aluno->ldlDataDois ?? " "); ?></td>
            <td><?php echo e($aluno->ldlValorDois ?? " "); ?></td>
            <td><?php echo e($aluno->tgDataUm ?? " "); ?></td>
            <td><?php echo e($aluno->tgValorUm ?? " "); ?></td>
            <td><?php echo e($aluno->tgDataDois ?? " "); ?></td>
            <td><?php echo e($aluno->tgValorDois ?? " "); ?></td>




































        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH /home/minski/Desktop/Faculdade/ClinicaEDF/resources/views/aluno/export_aluno.blade.php ENDPATH**/ ?>