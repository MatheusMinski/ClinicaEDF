<?php $__env->startSection('titulo','Lista de Espera'); ?>

<?php $__env->startSection('conteudo'); ?>
    <div class="container">
        <br/>
        <h3 class="center">Lista De Espera</h3>
        <?php if(isset($errors) && count ($errors) > 0): ?>
            <div class="alert alert-danger">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p align="center"><?php echo e($error); ?></p>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
        <br/><br/><br/>
        <div class="row">
            <table>
                <thead>
                <tr>
                    <th>Nome</th>
                    <th>Telefone</th>
                    <th>Outro contato</th>
                    <th>Prioridade</th>
                    <th>Status</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $lista; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $objeto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <!-- TODO: Aqui eu apenas usei como exemplo a tabela de equipamentos. Trocar para os nomes e informaçoes de quem está na lista de presença. -->
                <tr>
                    <td><?php echo e($objeto->nomeAlunoEspera); ?></td>
                    <td><?php echo e($objeto->telefone); ?></td>
                    <td><?php echo e($objeto->outroContato); ?></td>
                    <td><?php echo e($objeto->prioridade); ?></td>
                    <?php if($objeto->contatado): ?>
                        <td>Já foi contatado</td>
                    <?php else: ?>
                        <td>Não foi contatado</td>
                    <?php endif; ?>

                    <?php if(!$objeto->contatado): ?>
                        <td>
                            <a class="btn deep green" href="<?php echo e(route('lista.espera.contatado',$objeto->id)); ?>">Confirmar
                                Contato Realizado</a>
                        </td>
                    <?php endif; ?>
                    <td>
                        <a class="btn deep red" href="<?php echo e(route('lista.espera.remover',$objeto->id)); ?>">Remover</a>
                    </td>

                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        
        
        

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/minski/Desktop/Faculdade/ClinicaEDF/resources/views/listaespera.blade.php ENDPATH**/ ?>