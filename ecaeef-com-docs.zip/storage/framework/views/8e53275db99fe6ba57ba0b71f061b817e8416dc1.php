<?php $__env->startSection('titulo','Dados Principais'); ?>

<?php $__env->startSection('conteudo'); ?>

    <div class="container">
        <div class="col s12 m7">

            <div class="card horizontal" style="width: 45%; float: left; margin: 2%">

                <div class="card-stacked">
                    <div class="card-content" style="box-shadow:  15px 15px 27px #e1e1e3, 15px 15px 27px #ffffff;">
                        <h4 style="padding-bottom: 2%"><?php echo e($dadosAluno->nome); ?>:</h4>
                        <h6 style="padding-bottom: 10px">Data de Nascimento: <?php echo e(date('d/m/Y', strtotime($dadosAluno->dataNasc))); ?></h6>
                        <h6 style="padding-bottom: 10px">Idade: <?php echo e($dadosAluno->idade); ?></h6>
                        <h6 style="padding-bottom: 10px">Sexo: <?php echo e($dadosAluno->sexo); ?></h6>
                        <h6 style="padding-bottom: 10px">Telefone: <?php echo e($dadosAluno->telefone); ?></h6>
                        <h6 style="padding-bottom: 10px">Email: <?php echo e($dadosAluno->email); ?></h6>
                        <h6 style="padding-bottom: 10px">Profissão: <?php echo e($dadosAluno->profissao); ?></h6>
                        <h6 style="padding-bottom: 10px">Aposentado: <?php echo e($dadosAluno->aposentado); ?></h6>
                        <h6 style="padding-bottom: 10px">Estado Civil: <?php echo e($dadosAluno->estadoCivil); ?></h6>
                        <h6 style="padding-bottom: 10px">Escolaridade: <?php echo e($dadosAluno->escolaridade); ?></h6>
                        <h6 style="padding-bottom: 10px">Classe Social: <?php echo e($dadosAluno->classeSocialFamilia); ?></h6>
                        <a class="btn blue"  href="<?php echo e(route('aluno.cadastro.dados.editar', $dadosAluno->id)); ?>">Editar</a>
                    </div>
                </div>
            </div>


            <div class="card horizontal" style="width: 45%; float: left; margin: 2%">

                <div class="card-stacked">
                    <div class="card-content" style="box-shadow:  15px 15px 27px #e1e1e3, 15px 15px 27px #ffffff;">
                        <h5 style="padding-bottom: 10px">Endereço:</h5>
                        <h6 style="padding-bottom: 10px">Bairro: <?php echo e($dadosEndereco['bairro']); ?></h6>
                        <h6 style="padding-bottom: 10px">Rua: <?php echo e($dadosEndereco['rua']); ?></h6>
                        <h6 style="padding-bottom: 10px">Numero: <?php echo e($dadosEndereco['numero']); ?></h6>
                        <h6 style="padding-bottom: 10px">Cidade: <?php echo e($dadosEndereco['cidade']); ?></h6>
                        <h6 style="padding-bottom: 10px">CEP: <?php echo e($dadosEndereco['cep']); ?></h6>
                        <?php if($dadosEndereco['id'] == "Não cadastrado"): ?>
                            <a class="btn blue" href="<?php echo e(route('aluno.cadastro.endereco', ['idAluno' => $dadosAluno->id])); ?>">Cadastrar</a>
                        <?php else: ?>
                            <a class="btn blue"href="<?php echo e(route('aluno.cadastro.endereco.editar', $dadosEndereco['id'])); ?>">Editar</a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <div class="card horizontal" style="width: 45%; float: left; margin: 2%">

                <div class="card-stacked">
                    <div class="card-content" style="box-shadow:  15px 15px 27px #e1e1e3, 15px 15px 27px #ffffff;">
                        <h5 style="padding-bottom: 10px">Contato de Emergência:</h5>
                        <h6 style="padding-bottom: 10px">Nome: <?php echo e($dadosEmergencia['nome']); ?></h6>
                        <h6 style="padding-bottom: 10px">Parentesco: <?php echo e($dadosEmergencia['parentesco']); ?></h6>
                        <h6 style="padding-bottom: 10px">Telefone: <?php echo e($dadosEmergencia['telefone']); ?></h6>
                        <?php if($dadosEmergencia['id'] == "Não cadastrado"): ?>
                            <a class="btn blue" href="<?php echo e(route('aluno.cadastro.emergencia', ['idAluno' => $dadosAluno->id])); ?>">Cadastrar</a>
                        <?php else: ?>
                            <a class="btn blue"href="<?php echo e(route('aluno.cadastro.emergencia.editar', $dadosEmergencia['id'])); ?>">Editar</a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

        </div>



<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/minski/Desktop/Faculdade/ClinicaEDF/resources/views/aluno/aluno_dados_pessoais.blade.php ENDPATH**/ ?>