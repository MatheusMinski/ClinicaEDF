<?php $__env->startSection('titulo','Lista Professores'); ?>

<?php $__env->startSection('conteudo'); ?>
    <div class="container">
        <br/>
        <h3 class="center">Professores Cadastrados</h3>
        <br/><br/>
        <div style="padding: 30px; color: red" class="center">
            <?php if(isset($errors) && count ($errors) > 0): ?>
                <div class="alert alert-danger">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p><?php echo e($error); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
        </div>
        <br/><br/>
        <div class="row">
            <table>
                <thead>
                <tr>
                    <th>Nome</th>
                    <th>Telefone</th>
                    <th>Email</th>
                    <th>Histórico</th>
                    <form action=<?php echo e(route('professores.procurar')); ?> method="POST" role="search">
                        <?php echo e(csrf_field()); ?>

                        <th>
                            <input type="text" class="form-control" name="nomeProfessor"
                                   placeholder="Procurar Professores">
                        <th>
                            <button type="submit" class="btn btn-default">Procurar</button>
                        </th>
                    </form>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $registros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($registro->nome); ?></td>
                        <td><?php echo e($registro->telefone); ?></td>
                        <td><?php echo e($registro->email); ?></td>
                        <td><a class="btn yellow" href="<?php echo e(route('professor.status',$registro->idProfessor)); ?>">Histórico</a></td>
                        <?php if($registro->ativo): ?>
                            <td>
                                <a class="btn red"
                                   href="<?php echo e(route('inativar.professor',$registro->idProfessor)); ?>">Inativar</a>
                            </td>
                        <?php else: ?>
                            <td>
                                <a class="btn green" href="<?php echo e(route('reativar.professor',$registro->idProfessor)); ?>">Reativar</a>
                            </td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div class="row">
            <a class="btn blue" href="<?php echo e(route('cadastro.professor')); ?>">Cadastrar novo professor</a>
        </div>

        <div class="row" align="center">
            <?php echo e($registros->links('vendor.pagination.materializecss')); ?>

        </div>

    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/minski/Desktop/Faculdade/ClinicaEDF/resources/views/listaprofessores.blade.php ENDPATH**/ ?>