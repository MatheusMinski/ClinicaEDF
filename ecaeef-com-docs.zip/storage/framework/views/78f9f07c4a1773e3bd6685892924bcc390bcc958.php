<?php $__env->startSection('titulo', 'Login'); ?>

<?php $__env->startSection('conteudo'); ?>

    <div class="container" >
        <!--FORMULÁRIO DE LOGIN-->
        <div id="login" align="center">
            <form  method="post" action="<?php echo e(route('entrar')); ?>">
                <?php echo e(csrf_field()); ?>


                <br/>



                <h4>Login</h4>
                <div style="padding: 30px; color: red" class="center">
                    <?php if(isset($errors) && count ($errors) > 0): ?>
                        <div class="alert alert-danger">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <p><?php echo e($error); ?></p>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>
                </div>

                <div class="input-field" >
                <input id="email" required name="email" height="10px" style="width:350px; border-radius: 20px" type="text" class="validate" placeholder="E-mail"/>
                </div>


                <div class="input-field">
                <input id="password" required type="password" name="password" height="10px" style="width:350px; border-radius: 20px "class="validate" placeholder="Senha">
                </div>


                <div align="center" class="row">
                    <div><button type="submit" class="btn blue">Entrar</button>
                    <a class="btn green" href="<?php echo e(route('password.request')); ?>">Esqueci minha senha</a></div>
                </div>

            </form>


            <br/><br/><br/><br/>

        </div>
    </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/minski/Desktop/Faculdade/ClinicaEDF/resources/views/login.blade.php ENDPATH**/ ?>