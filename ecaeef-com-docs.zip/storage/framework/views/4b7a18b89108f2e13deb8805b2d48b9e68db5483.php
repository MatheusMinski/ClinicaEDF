<?php $__env->startSection('titulo','Anamnese'); ?>

<?php $__env->startSection('conteudo'); ?>
    <div class="container">
        <div class="row">
            <div class="card horizontal" style="width: 45%; float: left; margin: 2%">
                <div class="card-stacked">
                    <div class="card-content" style="box-shadow:  15px 15px 27px #e1e1e3, 15px 15px 27px #ffffff;">
                        <h6 style="padding-bottom: 10px">Encaminhameneto: <?php echo e($dadosAnamnese->encaminhamento); ?></h6>
                        <h6 style="padding-bottom: 10px">Nome do profissional: <?php echo e($dadosAnamnese->nomeDoProfissional); ?></h6>
                        <h6 style="padding-bottom: 10px">Especialidade: <?php echo e($dadosAnamnese->especialidadeDoProfissional); ?></h6>
                        <h6 style="padding-bottom: 10px">Motivo do encaminhamento: <?php echo e($dadosAnamnese->motivoEncaminhamento); ?></h6>
                        <h6 style="padding-bottom: 10px">Saúde geral: <?php echo e($dadosAnamnese->saudeGeral); ?></h6>
                        <h6 style="padding-bottom: 10px">Fuma cigarro: <?php echo e($dadosAnamnese->fumaCigarro); ?></h6>
                        <h6 style="padding-bottom: 10px">Quantidade: <?php echo e($dadosAnamnese->fumaCigarroQuantidadeDia); ?></h6>
                        <h6 style="padding-bottom: 10px">Já fumou antes: <?php echo e($dadosAnamnese->jaFumou); ?></h6>
                        <h6 style="padding-bottom: 10px">Quantos anos: <?php echo e($dadosAnamnese->jaFumouQuantidadeAnos); ?></h6>
                        <h6 style="padding-bottom: 10px">Parou a quanto tempo: <?php echo e($dadosAnamnese->jaFumouParouAQuantoTempoAnos); ?></h6>
                        <h6 style="padding-bottom: 10px">Descrição do problema de saúde: <?php echo e($dadosAnamnese->descricaoProblemaSaude); ?></h6>
                        <h6 style="padding-bottom: 10px">Caiu nos últimos 12 meses: <?php echo e($dadosAnamnese->caiu12Meses); ?></h6>
                        <h6 style="padding-bottom: 10px">Quantas vezes: <?php echo e($dadosAnamnese->quantasQuedas); ?></h6>
                        <h6 style="padding-bottom: 10px">Qual a data: <?php echo e(date('d/m/Y', strtotime($dadosAnamnese->data))); ?></h6>
                        <h6 style="padding-bottom: 10px">Qual a razão da queda: <?php echo e($dadosAnamnese->razaoQueda); ?></h6>
                        <h6 style="padding-bottom: 10px">Local da queda: <?php echo e($dadosAnamnese->localQueda); ?></h6>
                        <h6 style="padding-bottom: 10px">Foi hospitalizado: <?php echo e($dadosAnamnese->hospitalizacao); ?></h6>
                        <h6 style="padding-bottom: 10px">Objetivos ao procurar a clínica: <?php echo e($dadosAnamnese->objetivosAoProcurarAClinica); ?></h6>
                        <h6 style="padding-bottom: 10px">Já tentou resolver antes: <?php echo e($dadosAnamnese->jaTentouResolverAntes); ?></h6>
                        <h6 style="padding-bottom: 10px">Quantas vezes: <?php echo e($dadosAnamnese->quantasVezes); ?></h6>
                        <h6 style="padding-bottom: 10px">Já desistiu: <?php echo e($dadosAnamnese->jaDesistiu); ?></h6>
                        <h6 style="padding-bottom: 10px">Motivo da desistência: <?php echo e($dadosAnamnese->motivoDesistencia); ?></h6>
                        <a class="btn blue" style="margin-top: 5%"  href="<?php echo e(route('aluno.cadastro.anamnese.editar', $dadosAnamnese->idTreinamento)); ?>">Editar</a>
                    </div>
                </div>
            </div>

            <div class="card horizontal" style="width: 45%; float: left; margin: 2%">
                <div class="card-stacked">
                    <div class="card-content" style="box-shadow:  15px 15px 27px #e1e1e3, 15px 15px 27px #ffffff;">
                        <h6 style="padding-bottom: 10px">Dor em alguma região do corpo: <?php echo e($dadosAnamnese->dorRegiaoDoCorpo); ?></h6>
                        <h6 style="padding-bottom: 10px">Sintoma ou dor (1): <?php echo e($dadosAnamnese->descricaoSintomaDor1); ?></h6>
                        <h6 style="padding-bottom: 10px">Profissional que Tratou: <?php echo e($dadosAnamnese->ProfissionalQueTratou1); ?></h6>
                        <h6 style="padding-bottom: 10px">Início e fim do tratamento: <?php echo e($dadosAnamnese->inicioFim1); ?></h6>
                        <h6 style="padding-bottom: 10px">Escala da dor 0 a 10: <?php echo e($dadosAnamnese->EVA1); ?></h6>
                        <h6 style="padding-bottom: 10px">Sintoma ou dor (2): <?php echo e($dadosAnamnese->descricaoSintomaDor2); ?></h6>
                        <h6 style="padding-bottom: 10px">Profissional que Tratou: <?php echo e($dadosAnamnese->ProfissionalQueTratou2); ?></h6>
                        <h6 style="padding-bottom: 10px">Início e fim do tratamento: <?php echo e($dadosAnamnese->inicioFim2); ?></h6>
                        <h6 style="padding-bottom: 10px">Escala da dor 0 a 10: <?php echo e($dadosAnamnese->EVA2); ?></h6>
                        <h6 style="padding-bottom: 10px">Sintoma ou dor (3): <?php echo e($dadosAnamnese->descricaoSintomaDor3); ?></h6>
                        <h6 style="padding-bottom: 10px">Profissional que Tratou: <?php echo e($dadosAnamnese->ProfissionalQueTratou3); ?></h6>
                        <h6 style="padding-bottom: 10px">Início e fim do tratamento: <?php echo e($dadosAnamnese->inicioFim3); ?></h6>
                        <h6 style="padding-bottom: 10px">Escala da dor 0 a 10: <?php echo e($dadosAnamnese->EVA3); ?></h6>
                        <h6 style="padding-bottom: 10px">Sintoma ou dor (4): <?php echo e($dadosAnamnese->descricaoSintomaDor4); ?></h6>
                        <h6 style="padding-bottom: 10px">Profissional que Tratou: <?php echo e($dadosAnamnese->ProfissionalQueTratou4); ?></h6>
                        <h6 style="padding-bottom: 10px">Início e fim do tratamento: <?php echo e($dadosAnamnese->inicioFim4); ?></h6>
                        <h6 style="padding-bottom: 10px">Escala da dor 0 a 10: <?php echo e($dadosAnamnese->EVA4); ?></h6>
                        <h6 style="padding-bottom: 10px">Esforços para realizar as tarefas de casa, 0 a 10: <?php echo e($dadosAnamnese->esforcosTarefaCasa); ?></h6>
                        <h6 style="padding-bottom: 10px">Esforços para andar fora de casa 0 a 10: <?php echo e($dadosAnamnese->esforcoAndarForaDeCasa); ?></h6>
                        <h6 style="padding-bottom: 10px">Esforço ao realizar lazer 0 a 10: <?php echo e($dadosAnamnese->esforcoLazer); ?></h6>
                        <h6 style="padding-bottom: 10px">Esforço ao trabalhar: <?php echo e($dadosAnamnese->esforcoTrabalho); ?></h6>
                        <h6 style="padding-bottom: 10px">Pratica algum exercício físico: <?php echo e($dadosAnamnese->exercicioFisicoRegular); ?></h6>
                        <h6 style="padding-bottom: 10px">Quantas vezes por semana: <?php echo e($dadosAnamnese->quantasVezesSemana); ?></h6>
                        <h6 style="padding-bottom: 10px">Esforço para realizar esse exercício 0 a 10: <?php echo e($dadosAnamnese->esforcoParaEsseExercicio); ?></h6>

                        <a style="margin-top: 5%" class="btn blue"  href="<?php echo e(route('aluno.cadastro.anamnese.editar', $dadosAnamnese->idTreinamento)); ?>">Editar</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/minski/Desktop/Faculdade/ClinicaEDF/resources/views/aluno/aluno_anamnese.blade.php ENDPATH**/ ?>