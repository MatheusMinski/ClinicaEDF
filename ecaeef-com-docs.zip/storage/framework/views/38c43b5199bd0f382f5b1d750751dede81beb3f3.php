<?php $__env->startSection('titulo','Treinamentos'); ?>

<?php $__env->startSection('conteudo'); ?>
    <div class="container">
        <br/>
        <h3 class="center"><?php echo e($aluno->nome); ?></h3>
        <?php if(isset($errors) && count ($errors) > 0): ?>
            <div class="alert alert-danger">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p><?php echo e($error); ?></p>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
        <br/><br/><br/>
        <?php if($treinamentos != null): ?>
            <div class="row">
                <table>
                    <thead>
                    <tr>
                        <th>Data</th>
                        <th>Editar</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $treinamentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $treinamento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e(date('d/m/Y', strtotime($treinamento->created_at))); ?></td>
                            <td>
                                <a class="btn deep orange" href="<?php echo e(route('treinamento.status',$treinamento->id)); ?>">Status</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <div class="row" align="center">
                <?php echo e($treinamentos->links('vendor.pagination.materializecss')); ?>

            </div>
        <?php else: ?>
            <h4 class="center">O aluno ainda não possui treinamentos</h4>
        <?php endif; ?>
        <div style="margin-top: 20px;" class="container">
            <a class="btn blue" href="<?php echo e(route('aluno.treinamento.adicionar', ['idAluno' => $idAluno])); ?>">Criar nova avaliação</a>
        </div>



    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/minski/Desktop/Faculdade/ClinicaEDF/resources/views/aluno/aluno_treinamentos.blade.php ENDPATH**/ ?>