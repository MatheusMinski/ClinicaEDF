@extends ('layout.site')

@section('titulo', 'Login')

@section('conteudo')

    <h2>Erro</h2>

@endsection
