@extends ('layout.site')

@section('titulo', 'Home')

@section('conteudo')
    <!doctype html>
<html>
<head>


    <title>eCAEEF Home Page</title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

    <!-- Styles -->

</head>
<body>
<div class="content">
    <div class="center" style="padding-top: 50px">
        <img id="logo" src="https://i.ibb.co/Z2kjgcb/as.jpg" alt="as" border="0">
    </div>
</div>
</div>
</body>
</html>

@endsection
