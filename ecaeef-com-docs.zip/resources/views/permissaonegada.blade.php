@extends ('layout.site')

@section('titulo', 'Permissão Negada')

@section('conteudo')
<!doctype html>
<html>
<head>


    <title>eCAEEF Home Page</title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

    <!-- Styles -->

</head>
<body>
<div class="content">
    <div class="center">
        <br/><br/><br/><br/><br/><br/><br/><br/><br/>
        <h1 id="negada">Permissão Negada!</h1>
    </div>
</div>
</div>
</body>
</html>

@endsection
