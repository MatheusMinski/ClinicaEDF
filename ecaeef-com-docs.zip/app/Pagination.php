<?php namespace App;

use Landish\Pagination\Materialize;


class Pagination extends Materialize {


}
